//
//  MovieGridCell.swift
//  Applewhite Flixster
//
//  Created by Lyndon Applewhite on 2/6/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
